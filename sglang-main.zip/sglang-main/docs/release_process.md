```
pip install build twine
```

```
cd python
bash upload_pypi.sh
```